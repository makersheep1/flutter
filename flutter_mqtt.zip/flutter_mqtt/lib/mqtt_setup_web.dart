import 'package:mqtt_client/mqtt_browser_client.dart';

MqttBrowserClient createServerClient(
  String host,
  String clientId,
  int port,
  String path,
) {
  var serverUrl = host;
  if (!serverUrl.startsWith('ws://') && !serverUrl.startsWith('wss://')) {
    serverUrl = 'ws://$serverUrl';
  }
  var normalizedPath = path.trim();
  if (normalizedPath.isNotEmpty && !normalizedPath.startsWith('/')) {
    normalizedPath = '/$normalizedPath';
  }
  final fullUrl = '$serverUrl:$port$normalizedPath';
  return MqttBrowserClient(fullUrl, clientId);
}
