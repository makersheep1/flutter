import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb, debugPrint, ChangeNotifier;
import 'package:mqtt_client/mqtt_client.dart';
import 'mqtt_setup_native.dart' if (dart.library.html) 'mqtt_setup_web.dart';

class MqttService extends ChangeNotifier {
  MqttClient? client;
  MqttConnectionState connectionState = MqttConnectionState.disconnected;
  List<String> messages = [];
  String? lastTopic;

  // 连接状态
  bool get isConnected =>
      client?.connectionStatus?.state == MqttConnectionState.connected;

  // 连接到 MQTT Broker
  Future<bool> connect({
    required String host,
    required int port,
    required String clientId,
    String? username,
    String? password,
    String path = '/mqtt',
  }) async {
    client = createServerClient(host, clientId, port, path);
    
    // 公共设置
    client!.keepAlivePeriod = 20;
    client!.onDisconnected = _onDisconnected;
    client!.onConnected = _onConnected;
    client!.onSubscribed = _onSubscribed;
    client!.pongCallback = _pong;

    // 显式设置协议版本为 3.1.1 (NanoMQ 推荐)
    client!.setProtocolV311();

    // 在 Android/iOS 上开启日志，方便调试
    if (!kIsWeb) {
      client!.logging(on: true);
    }

    if (kIsWeb) {
      try {
        (client as dynamic).websocketProtocols = ['mqtt'];
      } catch (e) {
        debugPrint('MQTT: Web specific setup failed: $e');
      }
    }

    final connMessage = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .startClean(); // 移除 .withWillQos(MqttQos.atLeastOnce)

    if (username != null && username.isNotEmpty) {
      connMessage.authenticateAs(username, password);
    }
    
    client!.connectionMessage = connMessage;

    try {
      debugPrint('MQTT: Connecting to ${client!.server}:${client!.port}...');
      await client!.connect();
    } catch (e) {
      debugPrint('MQTT: Exception during connection: $e');
      disconnect();
      return false;
    }

    if (client!.connectionStatus!.state == MqttConnectionState.connected) {
      debugPrint('MQTT: Connected');
      
      // 监听消息
      client!.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
        final recMess = c![0].payload as MqttPublishMessage;
        final pt = MqttPublishPayload.bytesToStringAsString(recMess.payload.message);
        
        String message = '[${c[0].topic}] $pt';
        messages.insert(0, message);
        notifyListeners();
      });
      
      return true;
    } else {
      debugPrint('MQTT: Connection failed - state is ${client!.connectionStatus!.state}');
      disconnect();
      return false;
    }
  }

  // 断开连接
  void disconnect() {
    client?.disconnect();
    _onDisconnected();
  }

  // 订阅主题
  void subscribe(String topic) {
    if (isConnected) {
      debugPrint('MQTT: Subscribing to $topic');
      client!.subscribe(topic, MqttQos.atLeastOnce);
      lastTopic = topic;
    }
  }

  // 发布消息
  void publish(String topic, String message) {
    if (isConnected) {
      final builder = MqttClientPayloadBuilder();
      builder.addString(message);
      client!.publishMessage(topic, MqttQos.atLeastOnce, builder.payload!);
      debugPrint('MQTT: Published $message to $topic');
    }
  }

  // 回调函数
  void _onConnected() {
    connectionState = MqttConnectionState.connected;
    debugPrint('MQTT: OnConnected');
    notifyListeners();
  }

  void _onDisconnected() {
    connectionState = MqttConnectionState.disconnected;
    debugPrint('MQTT: OnDisconnected');
    notifyListeners();
  }

  void _onSubscribed(String topic) {
    debugPrint('MQTT: OnSubscribed to $topic');
  }

  void _pong() {
    debugPrint('MQTT: Ping response received');
  }

  void clearMessages() {
    messages.clear();
    notifyListeners();
  }
}
