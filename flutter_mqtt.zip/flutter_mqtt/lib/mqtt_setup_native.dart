import 'package:mqtt_client/mqtt_server_client.dart';

MqttServerClient createServerClient(
  String host,
  String clientId,
  int port,
  String path,
) {
  return MqttServerClient.withPort(host, clientId, port);
}
