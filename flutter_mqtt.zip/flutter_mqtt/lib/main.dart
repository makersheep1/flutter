import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:provider/provider.dart';
import 'mqtt_service.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => MqttService(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter MQTT Client',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const MqttHomePage(),
    );
  }
}

class MqttHomePage extends StatefulWidget {
  const MqttHomePage({super.key});

  @override
  State<MqttHomePage> createState() => _MqttHomePageState();
}

class _MqttHomePageState extends State<MqttHomePage> {
  // 控制器
  final TextEditingController _hostController = TextEditingController(text: '127.0.0.1');
  late final TextEditingController _portController;
  final TextEditingController _clientIdController = TextEditingController(text: 'flutter_client_${DateTime.now().millisecondsSinceEpoch}');
  final TextEditingController _topicController = TextEditingController(text: 'test/topic');
  final TextEditingController _messageController = TextEditingController(text: 'Hello from Flutter!');
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _pathController = TextEditingController(text: '/mqtt');

  @override
  void initState() {
    super.initState();
    // 根据平台设置默认端口：Web 默认 8083 (WS)，其他默认 1883 (TCP)
    _portController = TextEditingController(text: kIsWeb ? '8083' : '1883');
  }

  @override
  void dispose() {
    _hostController.dispose();
    _portController.dispose();
    _clientIdController.dispose();
    _topicController.dispose();
    _messageController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _pathController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mqttService = Provider.of<MqttService>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter MQTT Client'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            onPressed: mqttService.clearMessages,
            tooltip: '清除消息',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 连接配置卡片
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    const Text('连接设置', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    TextField(controller: _hostController, decoration: const InputDecoration(labelText: 'Host')),
                    TextField(controller: _portController, decoration: const InputDecoration(labelText: 'Port'), keyboardType: TextInputType.number),
                    TextField(controller: _clientIdController, decoration: const InputDecoration(labelText: 'Client ID')),
                    if (kIsWeb)
                      TextField(controller: _pathController, decoration: const InputDecoration(labelText: 'WebSocket Path (e.g. /mqtt)')),
                    TextField(controller: _usernameController, decoration: const InputDecoration(labelText: 'Username (Optional)')),
                    TextField(controller: _passwordController, decoration: const InputDecoration(labelText: 'Password (Optional)'), obscureText: true),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: mqttService.isConnected ? Colors.red : Colors.green,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        final messenger = ScaffoldMessenger.of(context);
                        if (mqttService.isConnected) {
                          mqttService.disconnect();
                        } else {
                          bool success = await mqttService.connect(
                            host: _hostController.text,
                            port: int.parse(_portController.text),
                            clientId: _clientIdController.text,
                            username: _usernameController.text,
                            password: _passwordController.text,
                            path: _pathController.text,
                          );
                          if (!mounted) return;
                          if (!success) {
                            messenger.showSnackBar(
                              const SnackBar(content: Text('连接失败，请检查设置')),
                            );
                          }
                        }
                      },
                      child: Text(mqttService.isConnected ? '断开连接' : '连接服务器'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 订阅与发布卡片
            if (mqttService.isConnected) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    children: [
                      const Text('订阅与发布', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(controller: _topicController, decoration: const InputDecoration(labelText: '主题 (Topic)')),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () => mqttService.subscribe(_topicController.text),
                            child: const Text('订阅'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(controller: _messageController, decoration: const InputDecoration(labelText: '消息 (Message)')),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () => mqttService.publish(_topicController.text, _messageController.text),
                            child: const Text('发布'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],

            // 消息列表
            const Text('接收到的消息:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Divider(),
            Container(
              height: 300,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: mqttService.messages.isEmpty
                  ? const Center(child: Text('暂无消息'))
                  : ListView.builder(
                      itemCount: mqttService.messages.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(mqttService.messages[index]),
                          dense: true,
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
