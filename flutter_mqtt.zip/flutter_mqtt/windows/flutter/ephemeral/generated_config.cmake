# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\Flutter_SDK\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\wanghao\\Desktop\\flutter_mqtt" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\Flutter_SDK\\flutter"
  "PROJECT_DIR=C:\\Users\\wanghao\\Desktop\\flutter_mqtt"
  "FLUTTER_ROOT=D:\\Flutter_SDK\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\wanghao\\Desktop\\flutter_mqtt\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\wanghao\\Desktop\\flutter_mqtt"
  "FLUTTER_TARGET=C:\\Users\\wanghao\\Desktop\\flutter_mqtt\\lib\\main.dart"
  "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9WRVJTSU9OPTMuNDEuNA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZmYzN2JlZjYwMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZTRiOGRjYTNmMQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\wanghao\\Desktop\\flutter_mqtt\\.dart_tool\\package_config.json"
)
